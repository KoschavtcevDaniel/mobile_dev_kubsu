package com.example.list_4pm2_2425.app_view_models

import androidx.lifecycle.ViewModel

class StudentsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}