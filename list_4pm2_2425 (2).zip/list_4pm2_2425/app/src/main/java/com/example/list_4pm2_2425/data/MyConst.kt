package com.example.list_4pm2_2425.data

object MyConst {
    val TAG="com.example.list_temp.log"
}

enum class NamesOfFragment{
    FACULTY,GROUP,STUDENT
}