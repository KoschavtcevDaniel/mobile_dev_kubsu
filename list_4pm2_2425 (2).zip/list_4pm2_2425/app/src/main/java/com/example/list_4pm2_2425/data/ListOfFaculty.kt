package com.example.list_4pm2_2425.data

data class ListOfFaculty(
    var items: MutableList<Faculty> = mutableListOf()
)
