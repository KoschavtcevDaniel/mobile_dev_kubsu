package com.example.myfirstapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btn=findViewById<Button>(R.id.btnButton)
        btn.setOnClickListener{
            val num1=findViewById<EditText>(R.id.etInput2)
            var n1:Float? = null
            try{
                n1 = num1.text.toString().toFloat()
            } catch (nfe: NumberFormatException) {
                num1.error = "Введите число"
                num1.requestFocus()
            }

            val num2=findViewById<EditText>(R.id.etInput2)
            var n2:Float? = null
            try{
                n2 = num2.text.toString().toFloat()
            } catch (nfe: NumberFormatException) {
                num2.error = "Введите число"
                num2.requestFocus()
            }

            val etOp = findViewById<EditText>(R.id.etOperation)
            var oper: String = etOp.text.toString()
            if (oper.isBlank() or (oper.length > 1) or (!("+-/*".contains(oper)))){
                etOp.error = "Укажите верную операцию"
                etOp.requestFocus()
                oper = ""
            }

            if((n1==null) or (n2==null) or oper.isBlank()) return@setOnClickListener

            findViewById<TextView>(R.id.tvInfo).text= when (oper) {
                "*" -> {
                    (n1!! * n2!!).toString()
                }
                "+" -> {
                    (n1!! + n2!!).toString()
                }
                "-" -> {
                    (n1!! - n2!!).toString()
                }
                "/" -> {
                    (n1!! / n2!!).toString()
                }
                else -> ""
            }
        }
    }

}