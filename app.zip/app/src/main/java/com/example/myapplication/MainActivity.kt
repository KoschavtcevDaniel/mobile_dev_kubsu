package com.example.myapplication

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.*

class MainActivity : AppCompatActivity() {

    var text1: TextView = findViewById(R.id.text1)
    var text2: TextView = findViewById(R.id.text2)
    var text3: EditText = findViewById(R.id.editTextView)

    var b1: Button = findViewById(R.id.b1)
    var b2: Button = findViewById(R.id.b2)
    var b3: Button = findViewById(R.id.b3)
    var b4: Button = findViewById(R.id.b4)
    var b5: Button = findViewById(R.id.b5)
    var b6: Button = findViewById(R.id.b6)
    var b7: Button = findViewById(R.id.b7)
    var b8: Button = findViewById(R.id.b8)
    var b9: Button = findViewById(R.id.b9)
    var b10: Button = findViewById(R.id.b10)
    var b11: Button = findViewById(R.id.b11)
    var b12: Button = findViewById(R.id.b12)
    var b13: Button = findViewById(R.id.b13)
    var b14: Button = findViewById(R.id.b14)
    var b15: Button = findViewById(R.id.b15)
    var b16: Button = findViewById(R.id.b16)
    var b17: Button = findViewById(R.id.b17)
    var b19: Button = findViewById(R.id.b19)

    private var firstNumber: Double? = null
    private var action: String? = null
    private var isNewOperation = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        b19.setOnClickListener {
            text1.text = ""
            text2.text = ""
            text3.setText("")
        }

        b16.setOnClickListener{
            val s = text1.text.toString()
            if (s != "") {
                text1.text = s.substring(0,s.length-1)
        }

        b13.setOnClickListener {
            text1.text = (text1.text.toString() + "0")
        }
        b7.setOnClickListener {
            text1.text = (text1.text.toString() + "1")
        }
        b8.setOnClickListener {
            text1.text = (text1.text.toString() + "2")
        }
        b9.setOnClickListener {
            text1.text = (text1.text.toString() + "3")
        }
        b4.setOnClickListener {
            text1.text = (text1.text.toString() + "4")
        }
        b5.setOnClickListener {
            text1.text = (text1.text.toString() + "5")
        }
        b6.setOnClickListener {
            text1.text = (text1.text.toString() + "6")
        }
        b1.setOnClickListener {
            text1.text = (text1.text.toString() + "7")
        }
        b2.setOnClickListener {
            text1.text = (text1.text.toString() + "8")
        }
        b3.setOnClickListener {
            text1.text = (text1.text.toString() + "9")
        }
        b14.setOnClickListener {
            text1.text = (text1.text.toString() + ".")
        }
        b10.setOnClickListener {
            text1.text = (text1.text.toString() + "/")
        }
        b11.setOnClickListener {
            text1.text = (text1.text.toString() + "*")
        }
        b12.setOnClickListener {
            text1.text = (text1.text.toString() + "-")
        }
        b15.setOnClickListener {
            text1.text = (text1.text.toString() + "+")
        }

        fun onNumberClick(view: View) {
            if (isNewOperation) {
                text3.setText("")
                isNewOperation = false
            }

            val button = view as Button
            val number = button.text.toString()
            val currentText = text3.text.toString()
            text3.setText(currentText + number)
        }

        fun onActionClick(view: View) {
            val value = text3.text.toString()
            if (TextUtils.isEmpty(value)) {
                Toast.makeText(this, "Введите число", Toast.LENGTH_SHORT).show()
                return
            }

            firstNumber = value.toDoubleOrNull()
            if (firstNumber == null) {
                Toast.makeText(this, "Некорректный ввод", Toast.LENGTH_SHORT).show()
                return
            }

            val button = view as Button
            action = button.text.toString()
            text2.text = action
            text1.text = value
            isNewOperation = true
        }

        fun onEqualClick(view: View) {
            val value = text3.text.toString()
            if (TextUtils.isEmpty(value)) {
                Toast.makeText(this, "Введите число", Toast.LENGTH_SHORT).show()
                return
            }

            val secondNumber = value.toDoubleOrNull()
            if (secondNumber == null) {
                Toast.makeText(this, "Некорректный ввод", Toast.LENGTH_SHORT).show()
                return
            }

            val result = when (action) {
                "+" -> firstNumber?.plus(secondNumber)
                "-" -> firstNumber?.minus(secondNumber)
                "*" -> firstNumber?.times(secondNumber)
                "/" -> {
                    if (secondNumber == 0.0) {
                        Toast.makeText(this, "Деление на ноль!", Toast.LENGTH_SHORT).show()
                        null
                    } else {
                        firstNumber?.div(secondNumber)
                    }
                }
                else -> {
                    Toast.makeText(this, "Выберите операцию", Toast.LENGTH_SHORT).show()
                    null
                }
            }

            if (result != null) {
                text3.setText(result.toString())
                text1.text = ""
                text2.text = ""
                firstNumber = null
                action = null
                isNewOperation = true
            }
            }




    }



/*
    fun showResult() {
        try {
            val expression = getInputExpression()
            val result = Expression(expression).calculate()
            if (result.isNaN()) {
                // Show Error Message
                output.text = "Error"
                output.setTextColor(ContextCompat.getColor(this, R.color.red))
            } else {
                // Show Result
                output.text = DecimalFormat("0.######").format(result).toString()
                output.setTextColor(ContextCompat.getColor(this, R.color.neon_green))
            }
        } catch (e: Exception) {
            // Show Error Message
            output.text = "Error"
            output.setTextColor(ContextCompat.getColor(this, R.color.red))
        }

 */
    }
}






