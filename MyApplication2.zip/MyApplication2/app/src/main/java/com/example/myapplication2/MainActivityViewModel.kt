package com.example.myapplication2

import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {
    private val questionBlank = listOf(
        Question(R.string.q1, answer = false),
        Question(R.string.q2, answer = true),
        Question(R.string.q3, answer = true),
        Question(R.string.q4, answer = true),
        Question(R.string.q5, answer = false),
        Question(R.string.q6, answer = false),
        Question(R.string.q7, answer = true),
        Question(R.string.q8, answer = false),
        Question(R.string.q9, answer = false),
        Question(R.string.q10, answer = true),
    )
}