package com.example.ex2_home

import androidx.appcompat.app.AppCompatActivity
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.util.Date

private  val EXTRA_STUD_EDIT = "com.example.ex2_home.stud_edit"

class EditStudent : AppCompatActivity() {

    companion object{
        fun newIntent(
            packageContext: Context,
            edit: Boolean,
            name: String = "",
            surName: String = "",
            secName: String = "",
            birthday: String = "",
            faculty: String = "",
            group: String = "",
            ungroup: Int = 0,
            number: Int = 0,
        ): Intent {
            return Intent(packageContext, EditStudent::class.java).apply{
                putExtra("edit_mode", edit)
                putExtra("name", name)
                putExtra("surname", surName)
                putExtra("secName", secName)
                putExtra("birthday", birthday)
                putExtra("faculty", faculty)
                putExtra("group", group)
                putExtra("ungroup", ungroup)
                putExtra("number", number)
            }
        }
    }

    private  lateinit var saveButton: Button
    private  lateinit var cancelButton: Button
    private lateinit var nameET: EditText
    private lateinit var surnameET: EditText
    private lateinit var secNameET: EditText
    private lateinit var facultyET: EditText
    private lateinit var groupET: EditText
    private lateinit var ungroupET: EditText
    private lateinit var birthdayET: EditText
    private lateinit var numbET: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val isEdit = intent?.getBooleanExtra("edit_mode", false)

        nameET = findViewById(R.id.ed1)
        surnameET = findViewById(R.id.ed2)
        secNameET = findViewById(R.id.ed3)
        birthdayET = findViewById(R.id.ed4)
        facultyET = findViewById(R.id.ed5)
        groupET = findViewById(R.id.ed6)
        ungroupET = findViewById(R.id.ed7)
        numbET = findViewById(R.id.ed8)

        // заполнение эдит полей имеющимися данными
        if (isEdit!!) {
            nameET.setText(intent.getStringExtra("name"))
            surnameET.setText(intent.getStringExtra("surname"))
            secNameET.setText(intent.getStringExtra("secName"))
            birthdayET.setText(intent.getStringExtra("birthday"))
            facultyET.setText(intent.getStringExtra("faculty"))
            groupET.setText(intent.getStringExtra("group"))
            ungroupET.setText(intent.getIntExtra("ungroup", 0).toString())
            numbET.setText(intent.getIntExtra("number", 0).toString())
        }

        // кнопка сохранить
        saveButton = findViewById(R.id.btsave)
        saveButton.setOnClickListener{
            if (nameET.text.isNullOrEmpty() || surnameET.text.isNullOrEmpty() || secNameET.text.isNullOrEmpty() || facultyET.text.isNullOrEmpty() || groupET.text.isNullOrEmpty() || ungroupET.text.isNullOrEmpty() || numbET.text.isNullOrEmpty()){
                Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show()
            }else if (nameET.text.toString().contains(Regex("[0-9]+")) || surnameET.text.toString().contains(Regex("[0-9]+")) || secNameET.text.toString().contains(Regex("[0-9]+")) || facultyET.text.toString().contains(Regex("[0-9]+")) || groupET.text.toString().contains(Regex("[0-9]+")) || groupET.text.toString().contains(Regex("[a-Я]+"))){
                Toast.makeText(this, "В полях с текстом присутствуют цифры", Toast.LENGTH_SHORT).show()
            }else{
                val data = Intent().apply {
                    putExtra(EXTRA_STUD_EDIT, true)
                    putExtra("name", nameET.text.toString())
                    putExtra("surname", surnameET.text.toString())
                    putExtra("secName", secNameET.text.toString())
                    putExtra("birthday", birthdayET.text.toString())
                    putExtra("faculty", facultyET.text.toString())
                    putExtra("group", groupET.text.toString())
                    putExtra("ungroup", ungroupET.text.toString().toInt())
                    putExtra("number", numbET.text.toString().toInt())
                }
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }

        // кнопка отмены
        cancelButton = findViewById(R.id.btdel)
        cancelButton.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }
}