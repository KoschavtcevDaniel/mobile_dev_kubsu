package com.example.ex2_home

import java.util.Date

data class Student(val Name : String, val Sur : String, val SecName : String, val Birthday: String, val Faculty : String, val Group : String, val UnGroup : Int, val Number : Int)
