package com.example.ex2_home

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val EXTRA_STUD_EDIT = "com.example.ex2_home.stud_edit"

class MainActivity : AppCompatActivity() {

    private  lateinit var btnChange : Button
    private  lateinit var name: TextView
    private  lateinit var surname: TextView
    private  lateinit var secName: TextView
    private  lateinit var faculty: TextView
    private  lateinit var group: TextView
    private  lateinit var ungroup: TextView
    private  lateinit var birthday: TextView
    private  lateinit var number: TextView

    var stud = Student("Имя", "Фамилия", "Отчество", "Дата рождения", "Факультет", "Группа", 0, 0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        name = findViewById(R.id.tv1)
        surname = findViewById(R.id.tv2)
        secName = findViewById(R.id.tv3)
        birthday = findViewById(R.id.tv4)
        faculty = findViewById(R.id.tv5)
        group=findViewById(R.id.tv6)
        ungroup=findViewById(R.id.tv6)
        number=findViewById(R.id.tv6)
        btnChange=findViewById(R.id.btnChange)


        // функция обновления текствью
        fun updateView() {
            name.text = "Имя: " + stud.Name
            surname.text = "Фамилия: " + stud.Sur
            secName.text = "Отчество: " + stud.SecName
            birthday.text = "День рождения: " + stud.Birthday
            faculty.text = "Факультет: " + stud.Faculty
            group.text = "Группа: " + stud.Group
            group.text = "Подгруппа: " + stud.UnGroup.toString()
            number.text = "Билет: " + stud.Number.toString()
        }

        var isCreate = false

        // заполнение текствью новыми данными
        val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
                result ->
            if (result.resultCode == Activity.RESULT_OK){
                val data: Intent? = result.data
                isCreate = data?.getBooleanExtra(EXTRA_STUD_EDIT, false) ?: false
                val name = result.data?.getStringExtra("name") ?: ""
                val surName = result.data?.getStringExtra("surname") ?: ""
                val secName = result.data?.getStringExtra("secName") ?: ""
                val birthday = result.data?.getStringExtra("birthday") ?: ""
                val faculty = result.data?.getStringExtra("faculty") ?: ""
                val group = result.data?.getStringExtra("group") ?: ""
                val ungroup = result.data?.getIntExtra("ungroup", 0) ?: 0
                val number = result.data?.getIntExtra("number", 0) ?: 0
                stud = Student(name, surName, secName, birthday, faculty, group, ungroup, number)
                updateView()
            }
        }

        // кнопка редактировать
        findViewById<Button>(R.id.btnChange).setOnClickListener{
            val intent = EditStudent.newIntent(this@MainActivity, isCreate, stud.Name, stud.Sur, stud.SecName, stud.Birthday, stud.Faculty, stud.Group, stud.UnGroup, stud.Number)
            resultLauncher.launch(intent)
        }

    }
}