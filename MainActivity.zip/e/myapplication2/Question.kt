package com.example.myapplication2

import androidx.annotation.StringRes

data class Question(@StringRes val textResId: Int, val answer: Boolean)

