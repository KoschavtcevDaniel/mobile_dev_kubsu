package com.example.list_4pm2_2425.data

data class ListOfGroup(
    var items: MutableList<Group> = mutableListOf()
)
